MADAL Android icon and build workflow

1. Extract this ZIP on your Android phone.
2. Open the GitHub repository and choose Add file > Upload files.
3. Upload these four PNG files from the extracted assets folder to the repository ROOT:
   icon-only.png
   icon-foreground.png
   icon-background.png
   splash.png
   (Do not upload the assets folder itself.)
4. Open .github/workflows/build-apk.yml and replace its contents with the
   supplied build-apk.yml file.
5. Commit the changes. GitHub Actions will build the Android APK.
6. Download the MADAL-Android-APK artifact from the successful run.

The workflow copies the four PNG files into the assets folder during build,
then generates Android launcher icons using @capacitor/assets.
